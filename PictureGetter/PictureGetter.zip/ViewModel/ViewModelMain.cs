﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.ObjectModel;
using System.Windows.Forms;

using PictureGetter.Model;
using PictureGetter.Helper;

namespace PictureGetter.ViewModel
{
    public class ViewModelMain : ViewModelBase
    {
        public ViewModelMain()
        {
            SelectSourceDirectoryCommand = new RelayCommand(SelectSourceDirectory);
            SelectDestinationDirectoryCommand = new RelayCommand(SelectDestinationDirectory);

            CopyDetails = new CopyDetails();
        } 

        public RelayCommand SelectSourceDirectoryCommand { get; set; }
        private void SelectSourceDirectory(object obj)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                DialogResult result = dialog.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
                {                    
                    CopyDetails.Source = dialog.SelectedPath;
                    
                    DirectoryInfo directoryInfo = new DirectoryInfo(CopyDetails.Source);
                    FileInfo[] fileInfo = directoryInfo.GetFiles();

                    SourceMediaFiles = new ObservableCollection<MediaFile>();

                    foreach(var file in fileInfo)
                    {
                        MediaFile record = new MediaFile();
                        record.Name = file.Name;
                        record.Path = file.DirectoryName;
                        record.CreatedDate = file.CreationTime;

                        SourceMediaFiles.Add(record);
                    }
                }
            }
        }

        public RelayCommand SelectDestinationDirectoryCommand { get; set; }
        private void SelectDestinationDirectory(object obj)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                DialogResult result = dialog.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
                {
                    CopyDetails.Destination = dialog.SelectedPath;
                }
            }
        }

        private CopyDetails _copyDetails;
        public CopyDetails CopyDetails
        {
            get
            {
                return _copyDetails;
            }

            set
            {
                _copyDetails = value;
                RaisePropertyChangedEvent("CopyDetails");
            }
        }

        private ObservableCollection<MediaFile> _sourceMediaFiles;
        public ObservableCollection<MediaFile> SourceMediaFiles
        {
            get { return _sourceMediaFiles; }
            set { _sourceMediaFiles = value;
                RaisePropertyChangedEvent("SourceMediaFiles");
            }
        }
    }
}
