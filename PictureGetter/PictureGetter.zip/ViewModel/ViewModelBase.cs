﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Threading;

using PictureGetter.Helper;

namespace PictureGetter.ViewModel
{
    public class ViewModelBase : ObservableObject
    {

    }
}
